﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InputManager : MonoBehaviour
{
    private ShipBehaviour player;
    public Weapons weapons;

    private GameManager gameManager;

	// Use this for initialization
	void Start ()
    {
        // player = GameObject.Find("PlayerShip").GetComponent<PlayerBehaviour>();
        player = GameObject.FindGameObjectWithTag("Player").GetComponent<ShipBehaviour>();
        gameManager = GetComponent<GameManager>();
	}
	
	// Update is called once per frame
	void Update ()
    {     
        if(Input.GetKeyDown(KeyCode.P))
        {
            if(gameManager.gamePaused) gameManager.Resume();
            else gameManager.Pause();
        }

        if(gameManager.gamePaused) return;

        Vector2 inputAxis = Vector2.zero;
        inputAxis.x = Input.GetAxis("Horizontal");
        inputAxis.y = Input.GetAxis("Vertical");
        player.SetAxis(inputAxis);

        if(Input.GetButton("Fire1"))
        {
            weapons.ShotWeapon();
        }

        if(Input.GetKeyDown(KeyCode.Q))
        {
            weapons.PreviousWeapon();
        }
        if(Input.GetKeyDown(KeyCode.E))
        {
            weapons.NextWeapon();
        }


    }
}
