﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MeteorBehaviour : ShipBehaviour
{
    public Animator anim;
    public ParticleSystem trailPS;
    public ParticleSystem explosionPS;
    public Sprite[] sprites;
    private RotateTransform rotateTransform;
    public int score = 10;

    protected override void Start()
    {
        rotateTransform = GetComponent<RotateTransform>();
        rotateTransform.EnableRotation(true);

        life = 6;
        base.Start();

        anim.enabled = false;
        rend.sprite = sprites[0];
        
    }

    private void DestroyMeteor()
    {
        GetComponent<Collider2D>().enabled = false;

        anim.enabled = true;
        anim.SetTrigger("Destroy");
        explosionPS.Play();
        trailPS.Stop();

        gameManager.AddScore(score);

        Destroy(gameObject, 1.5f);

    }

    public override void Damage(int hit)
    {
        base.Damage(hit);
        
        if(life == 2) { rend.sprite = sprites[1]; }
        if(life == 1) { rend.sprite = sprites[2]; }
    }
    protected override void Dead()
    {
        base.Dead();

        canFly = false;
        rotateTransform.EnableRotation(false);
        DestroyMeteor();
    }

    protected override void ResetShip()
    {
        Destroy(gameObject);
    }

    protected override void Update()
    {
        if(Input.GetKeyDown(KeyCode.T)) Damage(1);

        base.Update();
    }

    protected override void OnTriggerEnter2D(Collider2D collision)
    {
        base.OnTriggerEnter2D(collision);

        if(collision.tag == "Player")
        {
            collision.GetComponent<ShipBehaviour>().Damage(collisionDamage);
            Dead();
        }
    }
}
