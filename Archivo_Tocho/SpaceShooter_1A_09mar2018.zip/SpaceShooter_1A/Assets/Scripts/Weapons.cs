﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public struct CartridgeProperties
{
    public GameObject bulletPrefab;
    public int maxAmmo;
}

public class Weapons : MonoBehaviour
{
    private Cannon[] cannons;
    private int selectedCannon = 0;
    
    public Transform ammoTransform;

    //TESTING
    //public CartridgeProperties[] properties;
    public Cartridge[] cartridge;
    public int selectedCartridge = 0;

    public GameObject[] bulletsResources;
    public int maxAmmo = 50;

    private void Start()
    {
        bulletsResources = Resources.LoadAll<GameObject>("Prefabs/Bullets");

        cannons = GetComponentsInChildren<Cannon>();
        selectedCannon = 0;

        cartridge = new Cartridge[bulletsResources.Length];

        Vector2 cartridgePos = ammoTransform.position; 
        for(int i = 0; i < cartridge.Length; i++)
        {
            GameObject obj = new GameObject();
            obj.name = "Cartridge_" + i;
            obj.transform.SetParent(ammoTransform);
            cartridge[i] = new Cartridge(bulletsResources[i], maxAmmo, obj.transform, cartridgePos);
            cartridgePos.y -= 1.0f;
        }
    }

    public void ShotWeapon()
    {
        cannons[selectedCannon].ShotCannon(cartridge[selectedCartridge]);
    }
    public void NextWeapon()
    {
        selectedCannon++;
        /*
         *  0 --> 1 
         *  1 --> 2 --> 0
         */
        if(selectedCannon >= cannons.Length)
        {
            selectedCannon = 0;
        }
    }
    public void PreviousWeapon()
    {
        selectedCannon--;

        /*
         * 1 --> 0
         * 0 --> -1 --> 1 cannons.Lenght - 1
         */

        if(selectedCannon < 0)
        {
            selectedCannon = cannons.Length - 1;
        }
    }

}
