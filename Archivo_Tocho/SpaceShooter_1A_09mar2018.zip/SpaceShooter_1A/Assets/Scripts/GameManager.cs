﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public bool gameOver;
    public int score;
    public bool gamePaused;
    private HUD hud;
    
    private void Awake()
    {
        hud = GameObject.FindGameObjectWithTag("HUD").GetComponent<HUD>();

        score = 0;
        hud.UpdateScoreText(score);
    }

    public void Resume()
    {
        gamePaused = false;
        Time.timeScale = 1;
        hud.ClosePausePanel();
    }
    public void Pause()
    {
        gamePaused = true;
        Time.timeScale = 0;
        hud.OpenPausePanel();
    }

    public void LoadScene(int numScene)
    {
        SceneManager.LoadScene(numScene);
    }

    public void AddScore(int newScore)
    {
        score += newScore;
        hud.UpdateScoreText(score);
    }

    private void SaveGame()
    {
        int highScore = 0;

        if(PlayerPrefs.HasKey("HighScore"))
        {
            highScore = PlayerPrefs.GetInt("HighScore");
        }
        if(score > highScore)
        {
            highScore = score;
        }

        PlayerPrefs.SetInt("Score", score);
        PlayerPrefs.SetInt("HighScore", highScore);
    }

    public void GameOver()
    {
        gameOver = true;
        SaveGame();

        LoadScene(2);
    }

    public void PlayerLife(int pLife)
    {
        hud.UpdatePlayerLifeText(pLife);
    }


}
