﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cartridge
{    
    private Bullet[] bullets;
    private int currentBullet = 0;

    public Cartridge() { }
    public Cartridge(GameObject bulletPrefab, int maxAmmo, Transform parent, Vector2 origin)
    {
        bullets = new Bullet[maxAmmo];
        Vector2 spawnpos = origin;

        for(int i = 0; i < maxAmmo; i++)
        {
            //Crear una bullet
            GameObject obj = GameObject.Instantiate(bulletPrefab, spawnpos, Quaternion.identity, parent);
            spawnpos.x -= 0.2f;
            obj.name = bulletPrefab.name + "_" +  i;

            // ejemplo nombre: "Cartridge_0_02_RedBullet_30"

            // Guardaremos la bullet en la posición "i" del array
            bullets[i] = obj.GetComponent<Bullet>();
        }
    }

    public Bullet GetBullet()
    {
        Bullet b = bullets[currentBullet];

        currentBullet++;
        if(currentBullet >= bullets.Length) currentBullet = 0;

        return b;
    }

    ~Cartridge() { }
}
