﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TripleCannon : Cannon
{
    public override void ShotCannon(Cartridge c)
    {
        if(!canShot) return;

        canShot = false;
        timeCounter = 0;        

        c.GetBullet().ShotBullet(transform.position, direction, 0);
        c.GetBullet().ShotBullet(transform.position, direction, -10);
        c.GetBullet().ShotBullet(transform.position, direction, 10);
    }
}
