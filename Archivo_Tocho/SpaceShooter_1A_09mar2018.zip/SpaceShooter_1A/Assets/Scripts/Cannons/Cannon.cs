﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cannon : MonoBehaviour
{
    //public int maxAmmo;
    //public Bullet[] bullets;

    //public GameObject bulletPrefab;
    //public Transform ammoTransform;

    //protected int currentBullet = 0;

    public float cooldown = 0.3f;
    protected float timeCounter = 0;
    protected bool canShot = false;

    public Vector2 direction = Vector2.up;
    public float zRot = 0;

    
	protected virtual void Start ()
    {
        //CreateBullets();
	}

    protected virtual void Update ()
    {
		if(!canShot)
        {
            timeCounter += Time.deltaTime;
            if(timeCounter >= cooldown) canShot = true;
        }
	}
/*
    protected virtual void CreateBullets()
    {
        bullets = new Bullet[maxAmmo];
        Vector2 spawnpos = ammoTransform.position;

        for(int i = 0; i < maxAmmo; i++)
        {
            //Crear una bullet
            GameObject obj =  Instantiate(bulletPrefab, spawnpos, Quaternion.identity, ammoTransform);
            spawnpos.x -= 0.2f;
            obj.name = "Bullet_" + i;

            // Guardaremos la bullet en la posición "i" del array
            bullets[i] = obj.GetComponent<Bullet>();
        }

        canShot = true;
    }    
    */
    public virtual void ShotCannon(Cartridge c)
    {
        if(!canShot) return;        

        canShot = false;
        timeCounter = 0;

        c.GetBullet().ShotBullet(transform.position, direction, zRot);

        //bullets[currentBullet].ShotBullet(transform.position, direction, zRot);

        //currentBullet++;
        //if(currentBullet >= bullets.Length) currentBullet = 0;
    }
}
