﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SnakeBullet : Bullet
{
    public float timeCounter = 0;
    public float changeDir = 0.2f;
    

    protected override void Update()
    {
        base.Update();
        if(shot)
        {
            timeCounter += Time.deltaTime;
            if(timeCounter >= changeDir)
            {
                float zRot = transform.rotation.eulerAngles.z;
                zRot *= -1;
                transform.rotation = Quaternion.Euler(0,0,zRot);
                timeCounter = 0;
            }
        }
    }

    public override void ShotBullet(Vector2 origin, Vector2 direction)
    {
        base.ShotBullet(origin, direction);
        timeCounter = changeDir/2;
    }

}
