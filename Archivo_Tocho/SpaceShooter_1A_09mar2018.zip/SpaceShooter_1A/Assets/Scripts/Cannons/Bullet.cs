﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    public float speed;
    public int damage;

    protected bool shot = false;
    private Vector2 iniPos;

    protected Vector2 dir;

    public AudioSource shotFX;

	// Use this for initialization
	protected virtual void Start ()
    {
        iniPos = transform.position;
	}
	
	// Update is called once per frame
	protected virtual void Update ()
    {
		if(shot)
        {
            transform.Translate(dir * speed * Time.deltaTime);

        }
	}

    public virtual void ShotBullet(Vector2 origin, Vector2 direction)
    {
        shot = true;
        transform.position = origin;
        dir = direction;

        if(shotFX != null)
        {
            shotFX.pitch = Random.Range(0.97f, 1.03f);
            shotFX.volume = Random.Range(0.95f, 1.05f);
            shotFX.Play();
        }
    }
    public virtual void ShotBullet(Vector2 origin, Vector2 direction, float zRot)
    {
        ShotBullet(origin, direction);

        transform.rotation = Quaternion.Euler(0, 0, zRot);
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if(collision.tag == "Boundary")
        {
            Reset();
        }
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.tag == "UFO")
        {
            Debug.Log("COLLISION UFO");
            //collision.GetComponent<ShipBehaviour>().Damage(damage);

            collision.gameObject.SendMessage("Damage", damage);
            Reset();
        }
    }

    private void Reset()
    {
        shot = false;
        transform.position = iniPos;
        transform.rotation = Quaternion.Euler(0, 0, 0);
    }
}
