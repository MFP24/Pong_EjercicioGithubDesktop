﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShipBehaviour : MonoBehaviour
{
    public Vector2 speed;
    public int life;
    protected int iniLife;
    public int collisionDamage;

    [SerializeField] protected SpriteRenderer rend;

    protected Vector2 axis;
    protected Vector2 currentVelocity; //currentVelocity = axis * speed;

    protected bool canFly = false;
    protected Vector2 iniPosition;

    protected bool isDead;

    protected GameManager gameManager;

    // Use this for initialization
    protected virtual void Start ()
    {
        gameManager = GameObject.FindGameObjectWithTag("GameController").GetComponent<GameManager>();

        rend = GetComponentInChildren<SpriteRenderer>();

        iniPosition = transform.position;
        iniLife = life;
	}
	
	// Update is called once per frame
	protected virtual void Update ()
    {
        if(!canFly) return;

        HorizontalMovement();
        VerticalMovement();

        // Move the player
        transform.Translate(currentVelocity * Time.deltaTime, Space.World);
	}

    public void SetAxis(Vector2 newAxis)
    {
        axis = newAxis;
    }

    protected virtual void HorizontalMovement()
    {
        currentVelocity.x = axis.x * speed.x;
    }
    protected virtual void VerticalMovement()
    {
        currentVelocity.y = axis.y * speed.y;
    }

    public void SetFly(bool f)
    {
        canFly = f;
    }
    protected virtual void ResetShip()
    {
        //Resetear la posicion inicial
        transform.position = iniPosition;
        //Dejar de volar
        canFly = false;
        //Recuperar su vida inicial
        life = iniLife;
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        if(isDead) return;

        if(collision.tag == "Boundary")
        {
            //Reset ship
            ResetShip();
        }
    }
    protected virtual void OnTriggerEnter2D(Collider2D collision)
    {

    }

    public virtual void Damage(int hit)
    {
        life -= hit;
        if(life <= 0)
        {
            life = 0;
            Dead();
        }
    }
    protected virtual void Dead()
    {
        isDead = true;
    }
}
