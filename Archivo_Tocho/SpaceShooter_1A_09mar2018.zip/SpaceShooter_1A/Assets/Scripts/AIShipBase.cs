﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AIShipBase : MonoBehaviour
{
    public Vector2 direction;
    private ShipBehaviour ship;

	// Use this for initialization
	void Start ()
    {
        Initialize();
    }	

    public void Initialize()
    {
        ship = GetComponent<ShipBehaviour>();

        direction.x = Random.Range(-direction.x, direction.x);

        ship.SetAxis(direction);
        ship.SetFly(true);
    }
}
