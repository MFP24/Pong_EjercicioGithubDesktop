﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameOverHud : MonoBehaviour
{
    public Text scoreText;
    public Text highScoreText;

	// Use this for initialization
	void Start ()
    {
        scoreText.text = "Score: " + PlayerPrefs.GetInt("Score").ToString("00000");
        highScoreText.text = "HighScore: " + PlayerPrefs.GetInt("HighScore").ToString("00000");
    }

    public void LoadScene(int numScene)
    {
        SceneManager.LoadScene(numScene);
    }
}
