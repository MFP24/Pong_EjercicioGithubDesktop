﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotateTransform : MonoBehaviour
{
    private float zRot;
    public float smooth;
    private bool canRotate;

	void Start ()
    {
        smooth = Random.Range(-smooth, smooth);        
	}	
	void Update ()
    {
        if(!canRotate) return;

        transform.rotation = Quaternion.Euler(0, 0, zRot);
        zRot += Time.deltaTime * smooth;
	}

    public void EnableRotation(bool e)
    {
        canRotate = e;
    }
}
