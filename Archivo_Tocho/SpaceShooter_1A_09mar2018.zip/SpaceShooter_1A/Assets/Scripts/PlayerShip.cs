﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerShip : ShipBehaviour
{
    protected override void Start()
    {
        canFly = true;

        base.Start();

        gameManager.PlayerLife(life);
    }

    protected override void HorizontalMovement()
    {
        if((axis.x < 0 && transform.position.x < -2.5f) || (axis.x > 0 && transform.position.x > 2.5f))
        {
            currentVelocity.x = 0;
            return;
        }

        base.HorizontalMovement();
    }

    protected override void VerticalMovement()
    {
        if((axis.y < 0 && transform.position.y < -4.5f) || (axis.y > 0 && transform.position.y > 4.5f))
        {
            currentVelocity.y = 0;
            return;
        }

        base.VerticalMovement();
    }

    protected override void Dead()
    {
        base.Dead();
        gameManager.GameOver();
    }

    public override void Damage(int hit)
    {
        base.Damage(hit);

        gameManager.PlayerLife(life);
    }

}
