﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameplayHUD : MonoBehaviour
{
    private int score;
    public Text scoreText;
    public Text lifeText;

    private void Start()
    {
        UpdateScoreText(0);
    }

    public void UpdateLifeText(int newLife)
    {
        lifeText.text = "x" + newLife.ToString("00");
    }
    public void UpdateScoreText(int newScore)
    {
        score += newScore;
        scoreText.text = score.ToString("00000");
    }

}
